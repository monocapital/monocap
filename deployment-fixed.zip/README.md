This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

# OpenPurpose Perfect Clone

This is a Next.js static site implementation featuring React components.

## Getting Started

First, run the development server:
